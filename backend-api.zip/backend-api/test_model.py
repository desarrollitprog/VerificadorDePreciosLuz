"""
Script de prueba para verificar que los modelos SQLAlchemy funcionan correctamente.
"""

from app.models import Producto, ProductoPrecio, ProductoOferta, TasaImpuesto
from app.database import SessionLocal, SessionLocalERP
from sqlalchemy import text


def test_imports():
    """Prueba 1: Verificar que los modelos se importan correctamente"""
    print("=" * 60)
    print("PRUEBA 1: Importación de Modelos")
    print("=" * 60)
    
    modelos = [
        ("Producto", Producto),
        ("ProductoPrecio", ProductoPrecio),
        ("ProductoOferta", ProductoOferta),
        ("TasaImpuesto", TasaImpuesto)
    ]
    
    for nombre, modelo in modelos:
        try:
            print(f"✅ {nombre:20} → Tabla: {modelo.__tablename__:30} Schema: {modelo.__table_args__.get('schema', 'dbo')}")
        except Exception as e:
            print(f"❌ {nombre}: Error - {e}")
    
    print()


def test_query_producto():
    """Prueba 2: Consultar un producto de la BD"""
    print("=" * 60)
    print("PRUEBA 2: Consultar Productos")
    print("=" * 60)
    
    db = SessionLocal()
    
    try:
        # Contar productos
        count = db.query(Producto).count()
        print(f"📊 Total de productos en BD: {count}")
        
        if count > 0:
            # Obtener el primer producto
            producto = db.query(Producto).first()
            print(f"\n✅ Primer producto encontrado:")
            print(f"   ID: {producto.Id}")
            print(f"   SKU: {producto.SKU}")
            print(f"   Código Barras: {producto.CodigoBarras}")
            print(f"   Nombre: {producto.Nombre}")
        else:
            print("⚠️  No hay productos en la base de datos")
            
    except Exception as e:
        print(f"❌ Error al consultar productos: {e}")
    finally:
        db.close()
    
    print()


def test_query_precio():
    """Prueba 3: Consultar precios"""
    print("=" * 60)
    print("PRUEBA 3: Consultar Precios")
    print("=" * 60)
    
    db = SessionLocal()
    
    try:
        # Contar precios
        count = db.query(ProductoPrecio).count()
        print(f"📊 Total de precios en BD: {count}")
        
        if count > 0:
            # Obtener el primer precio
            precio = db.query(ProductoPrecio).first()
            print(f"\n✅ Primer precio encontrado:")
            print(f"   ID: {precio.Id}")
            print(f"   ProductoId: {precio.ProductoId}")
            print(f"   PvPBase (Bs): {precio.PvPBase}")
            print(f"   PvPConversion ($): {precio.PvPConversion}")
            print(f"   IndIVA: {precio.IndIVA}")
        else:
            print("⚠️  No hay precios en la base de datos")
            
    except Exception as e:
        print(f"❌ Error al consultar precios: {e}")
    finally:
        db.close()
    
    print()


def test_query_oferta():
    """Prueba 4: Consultar ofertas activas"""
    print("=" * 60)
    print("PRUEBA 4: Consultar Ofertas Activas")
    print("=" * 60)
    
    db = SessionLocal()
    
    try:
        # Contar ofertas activas
        count = db.query(ProductoOferta).filter(ProductoOferta.IndActivo == True).count()
        print(f"📊 Total de ofertas activas: {count}")
        
        if count > 0:
            # Obtener la primera oferta activa
            oferta = db.query(ProductoOferta).filter(ProductoOferta.IndActivo == True).first()
            print(f"\n✅ Primera oferta activa encontrada:")
            print(f"   ID: {oferta.Id}")
            print(f"   ProductoId: {oferta.ProductoId}")
            print(f"   PrecioOfertaBs: {oferta.PrecioOfertaBs}")
            print(f"   PrecioOfertaUSD: {oferta.PrecioOfertaUSD}")
            print(f"   Activo: {oferta.IndActivo}")
        else:
            print("⚠️  No hay ofertas activas en la base de datos")
            
    except Exception as e:
        print(f"❌ Error al consultar ofertas: {e}")
    finally:
        db.close()
    
    print()


def test_query_tasa_iva():
    """Prueba 5: Consultar tasas de IVA en BD ERP"""
    print("=" * 60)
    print("PRUEBA 5: Consultar Tasas de IVA (BD ERP)")
    print("=" * 60)
    
    db_erp = SessionLocalERP()
    
    try:
        # Contar tasas de IVA
        count = db_erp.query(TasaImpuesto).count()
        print(f"📊 Total de tasas de IVA: {count}")
        
        if count > 0:
            # Obtener todas las tasas activas
            tasas = db_erp.query(TasaImpuesto).filter(TasaImpuesto.Activo == True).all()
            print(f"\n✅ Tasas de IVA activas:")
            for tasa in tasas:
                print(f"   ID: {tasa.Id} | Nombre: {tasa.Nombre:15} | Porcentaje: {tasa.Porcentaje}%")
        else:
            print("⚠️  No hay tasas de IVA en la base de datos")
            
    except Exception as e:
        print(f"❌ Error al consultar tasas de IVA: {e}")
    finally:
        db_erp.close()
    
    print()


def test_join_producto_precio():
    """Prueba 6: JOIN entre Producto y Precio (simulando consulta real)"""
    print("=" * 60)
    print("PRUEBA 6: JOIN Producto + Precio")
    print("=" * 60)
    
    db = SessionLocal()
    
    try:
        # Query con JOIN
        resultado = (
            db.query(Producto, ProductoPrecio)
            .join(ProductoPrecio, Producto.Id == ProductoPrecio.ProductoId)
            .first()
        )
        
        if resultado:
            producto, precio = resultado
            print(f"✅ JOIN exitoso:")
            print(f"\n   📦 Producto:")
            print(f"      SKU: {producto.SKU}")
            print(f"      Nombre: {producto.Nombre}")
            print(f"      Código: {producto.CodigoBarras}")
            print(f"\n   💰 Precio:")
            print(f"      Bs: {precio.PvPBase}")
            print(f"      $: {precio.PvPConversion}")
            print(f"      IVA ID: {precio.IndIVA}")
        else:
            print("⚠️  No se encontraron resultados para el JOIN")
            
    except Exception as e:
        print(f"❌ Error en JOIN: {e}")
    finally:
        db.close()
    
    print()


def test_buscar_por_codigo_barras():
    """Prueba 7: Buscar producto por código de barras (consulta real del endpoint)"""
    print("=" * 60)
    print("PRUEBA 7: Búsqueda por Código de Barras")
    print("=" * 60)
    
    db = SessionLocal()
    
    try:
        # Primero obtener un código de barras existente
        primer_producto = db.query(Producto).first()
        
        if not primer_producto:
            print("⚠️  No hay productos para probar")
            return
        
        codigo_prueba = primer_producto.CodigoBarras
        print(f"🔍 Buscando producto con código: {codigo_prueba}")
        
        # Buscar producto con precio (como lo hará el endpoint real)
        resultado = (
            db.query(Producto, ProductoPrecio)
            .join(ProductoPrecio, Producto.Id == ProductoPrecio.ProductoId)
            .filter(Producto.CodigoBarras == codigo_prueba)
            .first()
        )
        
        if resultado:
            producto, precio = resultado
            print(f"\n✅ Producto encontrado:")
            print(f"   SKU: {producto.SKU}")
            print(f"   Nombre: {producto.Nombre}")
            print(f"   Precio Bs: {precio.PvPBase}")
            print(f"   Precio $: {precio.PvPConversion}")
            
            # Buscar si tiene oferta
            oferta = (
                db.query(ProductoOferta)
                .filter(
                    ProductoOferta.ProductoId == producto.Id,
                    ProductoOferta.IndActivo == True
                )
                .first()
            )
            
            if oferta:
                print(f"\n   🏷️  Tiene oferta activa:")
                print(f"      Precio Oferta Bs: {oferta.PrecioOfertaBs}")
                print(f"      Precio Oferta $: {oferta.PrecioOfertaUSD}")
            else:
                print(f"\n   ℹ️  No tiene ofertas activas")
                
        else:
            print(f"❌ No se encontró el producto")
            
    except Exception as e:
        print(f"❌ Error en búsqueda: {e}")
    finally:
        db.close()
    
    print()


def main():
    """Ejecutar todas las pruebas"""
    print("\n")
    print("🧪" * 30)
    print(" PRUEBAS DE MODELOS SQLALCHEMY ".center(60, "="))
    print("🧪" * 30)
    print("\n")
    
    try:
        test_imports()
        test_query_producto()
        test_query_precio()
        test_query_oferta()
        test_query_tasa_iva()
        test_join_producto_precio()
        test_buscar_por_codigo_barras()
        
        print("=" * 60)
        print("✅ TODAS LAS PRUEBAS COMPLETADAS")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ ERROR CRÍTICO: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()