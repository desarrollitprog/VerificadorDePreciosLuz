from sqlalchemy import Column, Integer, Numeric, BigInteger
from ..database import Base

class ProductoPrecio(Base):
    """
    Modelo para la tabla Transaccional.ProductosxEmpaquexSucursal
    Contiene los precios de los productos.
    """
    __tablename__='ProductosxEmpaquexSucursal'
    __table_args__ = {'schema':'Transaccional'}

    # Campos
    IdProductosxEmpaquexSucursal = Column(
        "IdProductosxEmpaquexSucursal", BigInteger, primary_key=True, index=True
    )
    IdProducto = Column("IdProducto", Integer, nullable=False, index=True)

    # Precios
    PVPBase = Column("PVPBase", Numeric(18, 2), nullable=False)
    PVPConversion = Column("PVPConversion", Numeric(18, 2), nullable=True)

    # Indicador IVA (0/1)
    IndIVA = Column("IndIVA", Integer, nullable=True)

    def __repr__(self):
        return (
            "<ProductoPrecio("
            f"IdProducto={self.IdProducto}, "
            f"PVPBase={self.PVPBase}, "
            f"PVPConversion={self.PVPConversion}, "
            f"IndIVA={self.IndIVA}"
            ")>"
        )
