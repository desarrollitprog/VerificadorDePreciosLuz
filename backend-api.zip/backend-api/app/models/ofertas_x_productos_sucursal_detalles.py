from sqlalchemy import Column, Integer
from ..database import Base


class OfertasxProductosxSucursalesDetalles(Base):
    """
    Modelo para la tabla Transaccional.OfertasxProductosxSucursalesDetalles
    Relaciona la oferta por sucursal con el empaque.
    """

    __tablename__ = "OfertasxProductosxSucursalesDetalles"
    __table_args__ = {"schema": "Transaccional"}

    IdOfertaxProductoxSucursal = Column(
        "IdOfertaxProductoxSucursal", Integer, primary_key=True, index=True
    )
    IdEmpaque = Column("IdEmpaque", Integer, nullable=False, index=True)

    def __repr__(self):
        return (
            "<OfertasxProductosxSucursalesDetalles("
            f"IdOfertaxProductoxSucursal={self.IdOfertaxProductoxSucursal}, "
            f"IdEmpaque={self.IdEmpaque}"
            ")>"
        )
