from sqlalchemy import Column, Integer, String, Numeric, Boolean
from ..database import BaseERP


class TasaImpuesto(BaseERP):
    """
    Modelo para la tabla ConfiguracionPOS.TasasImpuestos
    Contiene las tasas de IVA y otros impuestos.
    
    IMPORTANTE: Este modelo usa BaseERP porque está en otra base de datos.
    """
    __tablename__ = "TasasImpuestos"
    __table_args__ = {"schema": "ConfiguracionPOS"}
    
    # Campos
    Id = Column(Integer, primary_key=True, index=True)
    Nombre = Column(String(100), nullable=False)
    Porcentaje = Column(Numeric(5, 2), nullable=False)  # Ejemplo: 16.00 para 16%
    Activo = Column(Boolean, nullable=False, default=True)
    
    def __repr__(self):
        return f"<TasaImpuesto(Id={self.Id}, Nombre='{self.Nombre}', Porcentaje={self.Porcentaje}%)>"
